<div class="sw_win_wrapper">
<div class="ci sw_widget sw_wrap">
<?php 

//echo $subview_print;

echo $this->load->view($subview, $this->data, TRUE);

?>
</div>
</div>