<div class="col-xs-12 col-sm-12">
<div class="alert alert-danger alert-dismissible" role="alert">
<?php echo __('Form is not properly populated, details below', 'sw_win');?>
</div>
</div>