<?php 

// App types: demo, cms
//$config['app_type'] = 'demo';

$config['lat'] = '46.3706305';

$config['lng'] = '16.1241102';

$config['maps_api_key'] = 'AIzaSyB0lxCRSHcNPBu5hq3wsmY1KhcBq5Tlwi8';

$config['date_format_js'] = '';

$config['date_format_php'] = '';



