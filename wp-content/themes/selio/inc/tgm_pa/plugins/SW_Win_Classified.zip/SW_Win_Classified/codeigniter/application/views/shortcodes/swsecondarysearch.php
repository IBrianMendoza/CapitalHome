
<form class="sw_search_secondary">

<?php _search_form_secondary(1); ?>


<div class="form-group  col-sm-12" style="">
    <div class="button-wrapper-1">
        <button id="search-start-secondary" type="submit" class="sw-search-start btn btn-primary btn-inversed btn-block">&nbsp;&nbsp;<?php echo __('Search', 'sw_win'); ?>&nbsp;&nbsp</button>
     
    </div><!-- /.select-wrapper -->
</div><!-- /.form-group -->
                               
</form>