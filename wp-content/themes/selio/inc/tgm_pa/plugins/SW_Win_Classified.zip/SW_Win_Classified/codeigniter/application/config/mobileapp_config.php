<?php 

$config['lang_config'] = array(
                                'en'=>array('id'=>1, 'name'=>'english'),
                                'hr'=>array('id'=>2, 'name'=>'croatian')
                                );

