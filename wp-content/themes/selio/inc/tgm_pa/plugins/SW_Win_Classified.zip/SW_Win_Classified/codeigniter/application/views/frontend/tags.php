<?php
    echo do_shortcode('[swmaplistings text_criteria="'.$listing_id_slug.'"]');
    
    echo do_shortcode('[swlistings text_criteria="'.$listing_id_slug.'"]');
?>