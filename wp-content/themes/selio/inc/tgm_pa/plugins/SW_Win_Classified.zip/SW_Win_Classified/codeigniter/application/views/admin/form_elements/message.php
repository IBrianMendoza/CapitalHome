<div class="col-xs-12 col-sm-12">
<div class="alert alert-success alert-dismissible" role="alert">
<?php echo $message;?>
</div>
</div>

