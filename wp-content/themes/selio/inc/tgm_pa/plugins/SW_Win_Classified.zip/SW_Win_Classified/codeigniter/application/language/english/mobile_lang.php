<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$lang['Something is wrong with request'] = 'Something is wrong with request';
$lang['Results available'] = 'Results available';

$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
$lang[''] = '';
